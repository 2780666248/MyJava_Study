package com.sym.pojo;


import lombok.Data;

@Data
public class User {
   String  user_id;
   String  user_name;
   String  user_password;
   String  user_email;
   String  user_head;
}
